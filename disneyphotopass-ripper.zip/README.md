# disneyphotopass_ripper

Download full-resolution photos from [disneyphotopass.eu](https://www.disneyphotopass.eu) (flex / no overlay via `GetGraphic.ashx`).

## Install

1. Open Chrome → **Extensions** → enable **Developer mode**.
2. Click **Load unpacked** and select this folder (or load `disneyphotopass-ripper.zip` if you use the zip).
3. Sign in on the PhotoPass site and open your **Photos** gallery.
4. Wait until thumbnails load.
5. Click the extension → **Download visible photos**.

Downloads use your browser session (you must be logged in). Only photos currently loaded on the page are collected; scroll the gallery if you need more dates.
